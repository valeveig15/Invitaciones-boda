# Invitación Valentina & Santiago — V11

## Estructura
- `index.html`
- `style.css`
- `script.js`
- `manifest.json`
- `assets/` (imágenes, textura y música)

## Publicación en GitHub Pages
1. Subí el contenido de esta carpeta a la raíz del repositorio.
2. En GitHub: Settings → Pages.
3. Elegí `Deploy from a branch`, rama `main`, carpeta `/ (root)`.
4. Guardá y esperá a que GitHub publique la URL.

## Sección de canciones
El botón **PROPONER CANCIÓN** abre un formulario modal. En esta versión está configurado como demostración en navegador: confirma la sugerencia, pero no la almacena en un servidor.
Para recibir las propuestas de todos los invitados hay que conectarlo a un backend o servicio de formularios.


## Cambios V12
- Se agregó una sección de Instagram de la pareja.
- `@instagram_de_la_pareja` es un placeholder: reemplazalo en `index.html` por el usuario real.
- Se agregó una sección **Info útil** con horarios, ubicaciones y un bloque editable para información adicional.
- El cierre final incluye:
  - `¡Gracias por acompañarnos en este momento tan importante!`
  - `¿TE GUSTÓ NUESTRO DEMO?`
  - `Contactanos · Invitaciones personalizadas`
  - `SEGUINOS EN INSTAGRAM`
  - `@artedecostudio`


## Cambio V13
La música del sitio fue reemplazada por el archivo proporcionado:
`Die With a Smile (JLAY EDITED)(1).mp3`.

Dentro del proyecto sigue guardada como `assets/track-02.mp3`, por lo que no fue necesario cambiar el código de reproducción.
